public class example{  
   void a() throws ArithmeticException{  
	throw new ArithmeticException("Calculation error"); 
   }  
   void b() throws ArithmeticException{  
	a();  
   }  
   void c(){  
	try{  
	   b();  
	}
	catch(ArithmeticException e){
	   System.out.println("ArithmeticException handled");
	}  
   }  
   public static void main(String args[]){  
	example obj=new example();  
	obj.c();  
	System.out.println("End Of Program");  
   }  
}