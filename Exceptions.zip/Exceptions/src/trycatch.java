public class trycatch{
   public static void main(String args[]) {
      int a,b;
      try {
         
         a = 0;
         b = 62 / a;
         System.out.println(b);
         System.out.println(" try block");
      }
      catch (ArithmeticException e) { 
         
         System.out.println("You should not divide a number by zero");
      }
      catch (Exception e) {
    System.out.println("Exception occurred");
      }
      System.out.println("I'm out of try-catch block in Java.");
   }
}